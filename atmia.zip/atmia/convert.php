<?php
	if(ISSET($_GET['btn_submit'])){
		$digit = $_GET['txt_digit'];
		$currency = $_GET['currency'];
		if($digit != ""){
			switch($currency){
				case "Dollar":
					$output = $digit * 82.08;
					echo"<label class='text-success' style='font-size:25px;'>$".(number_format($output))."</label>";
				break;
 
				case "PESO":
					$output = $digit * 1.51;
					echo"<center><label class='text-success' style='font-size:25px;'>&#8364;".(number_format($output))."</label></center>";
				break;
			}
		}
	}
?>
