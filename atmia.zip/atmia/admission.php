<?php
include('root/config.php');

$page_nm = "Admission";
$pageUrl = "admission.php";

if ($_GET['mode'] != '') {
$id = (int) $_REQUEST['id'];

if (isset($_POST['btn_submit'])) {

$country = $_POST['country'];
$language = $_POST['language'];

    //add record
        if ($_POST['id'] == '' && $_POST['mode'] == 'add') {
      $add_qry = "INSERT INTO tbl_admission SET 
           country='".$country."',
           language='".$language."'";     
            $ai_db->aiQuery($add_qry);
        $ai_core->aiGoPage($pageUrl . "?msg=1");
        }
    //edit record
    if ($_POST['id'] != '' && $_POST['mode'] == 'edit') {
            $editqry = "UPDATE tbl_admission SET 
            country='".$country."',
           language='".$language."' WHERE id=" . $id;
           
            $ai_db->aiQuery($editqry);
      
      $ai_core->aiGoPage($pageUrl . "?msg=2");
        }
    }
  //delete record
    if ($_GET['mode'] == 'delete' && $id != '') 
  {
    
    $qry_del_su = "Delete from tbl_admission WHERE id=".$id;
        $ai_db->aiQuery($qry_del_su);
    
    $ai_core->aiGoPage($pageUrl . "?msg=3");
    }
  //get data for edit
  if ($id != '') 
  {
        $qry = "SELECT * FROM tbl_admission WHERE id=" . $id;
        $row = $ai_db->aiGetQueryObj($qry);
  }
} 
else{
  //select all record
   $qry = "SELECT * FROM tbl_admission ORDER BY country ASC";
    $result = $ai_db->aiGetQueryObj($qry);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?>  </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<?php include('header.php'); ?>


<main id="main" class="main">
  <div class="row pt-2 pb-2">
    <?php include('menu.php');?>
    <div class="col-sm-10">
      <h4 class="pagetitle">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
 
  <div class="col-sm-2">
     <div class="float-sm-right">
      <?php if($_REQUEST['mode'] != 'add'){ ?>
        <a href="<?php echo $pageUrl .'?mode=add' ?>" class="btn btn-success m-1"> <i class="fa fa-plus"></i> <span>Add <?php echo $page_nm; ?></span> </a>
        <?php } ?>
     </div>
    </div>
  </div>
  <?php if ($_REQUEST['mode'] != '') { ?>
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">
              Admission<hr>
            </h5>
            <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
            <input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>" />
            
              <div class="col-md-6">
                  <label for="inputCountry" class="form-label">Country</label>
                 <select class="form-select" name="country">
                      <option value="">Selact Country</option>
            <?php
            $qrys = "SELECT * FROM ".DB_PREFIX."country WHERE status='active' ORDER BY id ASC";
            $rows = $ai_db->aiGetQueryObj($qrys);
            foreach($rows as $mcrow){
            ?>
            <option <?php if($row[0]->country == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->id; ?>"><?php echo $mcrow->countryname; ?></option>
            <?php } ?>
                     </select>
                </div>
                <div class="col-md-6">
                  <label for="inputLanguage" class="form-label">Language Examinaction</label>
                  <select class="form-select" name="language">
                      <option value="">Selact Language</option>

                     <?php
            $qrys = "SELECT * FROM ".DB_PREFIX."language WHERE status='active' ORDER BY id ASC";
            $rows = $ai_db->aiGetQueryObj($qrys);
            foreach($rows as $mcrow){
            ?>
            <option <?php if($row[0]->language == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->id; ?>"><?php echo $mcrow->language; ?></option>
            <?php } ?>

                     </select>
                </div>
                <div class="text-end">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
              </form> 
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } else { ?>
 <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-table"></i> List Of <?php echo $page_nm; ?></h5>

              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead class="text-center">
                  <tr>  
                    <th scope="col">Country Name</th>
                    <th scope="col">Language Examination</th>
                    <th>Last update</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
        ?>
                  <tr>
                    <td><?php echo $row->country;?></td>
                    <td><?php echo $row->language;?></td>
                    <td><?php echo date("d-m-Y g:i A", strtotime($row->last_update));?></td>
                   <td>
                        <a href="<?php echo $pageUrl."?mode=edit&id=".$row->id.""; ?>" class="btn btn-primary m-1">Edit</a>
                        <a href="<?php echo $pageUrl."?mode=delete&id=".$row->id.""; ?>" class="delete_check btn btn-danger m-1">Delete</a>
                    </td>
                  </tr>
                   <?php }}?>
                </tbody>
              </table>
              <!-- End Table with stripped rows-->

            </div>
          </div>

        </div>
      </div>
    </section> 
     <?php } ?>
</main>


<?php include('footer.php'); ?>