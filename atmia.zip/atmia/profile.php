<?php include('header.php'); ?>
<?php
include('../root/config.php');

$page_nm = "Profile";
$pageUrl = "profile.php";

$qry = "SELECT * FROM tbl_admin WHERE id=".$_SESSION['aid'];
$row = $ai_db->aiGetQueryObj($qry);
if (isset($_POST['btn_submit'])) {
    $uname = addslashes($_POST['uname']);
    $email = $_POST['email'];
    $old_pass = $_POST['old_pass'];
    $n_passs = md5($_POST['n_passs']);
    $qry = "UPDATE tbl_admin SET "
            . "username='" . $uname . "',"
            . "email='" . $email . "'";
    if ($old_pass != '') {
        $qry .= ",password='".$n_passs."'";
    }
    $qry .= " WHERE id='".$_SESSION['aid']."'";
    $ai_db->aiQuery($qry);
    ?>
    <script>
        alert('Your Profile Successfully Updated Try Using New Credential!');
          window.location.href = "logout.php";
    </script>
    <?php
  
}
?>
  <!-- ======= Sidebar ======= -->
  <?php include('menu.php');?>

 <main id="main" class="main">
  
  <div class="row pt-2 pb-2">
    <div class="col-sm-10">
      <h4 class="pagetitle">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
  </div>

<section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title2">Manage <?php echo $page_nm; ?><hr></h5>
                <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
            <input type="hidden" name="id" id="id" value="<?php echo @$_REQUEST['id']; ?>" />

                <div class="col-md-6">
                  <label for="inputName5" class="form-label">User Name</label>
                  <input type="text" class="form-control"id="uname" name="uname" value="<?php echo $row[0]->username; ?>">
                </div>
                <div class="col-md-6">
                  <label for="inputEmail5" class="form-label">Email</label>
                  <input type="email" class="form-control" id="email" name="email" value="<?php echo $row[0]->email; ?>">
                </div>
                <div class="col-md-4">
                  <label for="inputPassword5" class="form-label">Password</label>
                  <input type="password" class="form-control" id="old_pass" name="old_pass" placeholder="Enter Password" required />
                </div>
                <div class="col-4">
                  <label for="inputPassword5" class="form-label">New Password</label>
                  <input type="password" class="form-control"  placeholder="New Password" id="n_passs" name="n_passs">
                </div>
                <div class="col-4">
                  <label for="inputPassword5" class="form-label">Confirm Password</label>
                  <input type="password" class="form-control" placeholder="Confirm Password" id="cn_pass" name="cn_pass">
                </div>
                <div class="text-end">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php include('footer.php'); ?>