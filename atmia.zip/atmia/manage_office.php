<?php
include('root/config.php');
//include('header.php'); 

$page_nm = "Office";
$pageUrl = "manage_office.php";

if ($_GET['mode'] != '') {
$id = (int) $_REQUEST['id'];

if (isset($_POST['btn_submit'])) {

$office_name = $_POST['office_name'];
$status = $_POST['status'];

    //add record
        if ($_POST['id'] == '' && $_POST['mode'] == 'add') {
      $add_qry = "INSERT INTO  tbl_office SET 
           office_name='".$office_name."',
           status='".$status."'";        
            $ai_db->aiQuery($add_qry);
        $ai_core->aiGoPage($pageUrl . "?msg=1");
        }
    //edit record
    if ($_POST['id'] != '' && $_POST['mode'] == 'edit') {
            $editqry = "UPDATE  tbl_office SET 
           office_name='".$office_name."',
            status='".$status."' WHERE id=" . $id;
           
            $ai_db->aiQuery($editqry);
      
      $ai_core->aiGoPage($pageUrl . "?msg=2");
        }
    }
  //delete record
    if ($_GET['mode'] == 'delete' && $id != '') 
  {
    
    $qry_del_su = "Delete from  tbl_office WHERE id=".$id;
        $ai_db->aiQuery($qry_del_su);
    
    $ai_core->aiGoPage($pageUrl . "?msg=3");
    }
  //get data for edit
  if ($id != '') 
  {
        $qry = "SELECT * FROM  tbl_office WHERE id=" . $id;
        $row = $ai_db->aiGetQueryObj($qry);
  }
} 
else{
  //select all record
   $qry = "SELECT * FROM  tbl_office ORDER BY office_name ASC";
    $result = $ai_db->aiGetQueryObj($qry);
}
?>
<?php ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?>  </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
<?php include('header.php'); ?>
<?php include('menu.php');?>

 <main id="main" class="main">
  
 <div class="row pt-2 pb-2">
    <div class="col-sm-10">
      <h4 class="pagetitle">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
    <div class="col-sm-2">
     <div class="float-sm-right">
      <?php if(@$_REQUEST['mode'] != 'add'){ ?>
        <a href="<?php echo $pageUrl .'?mode=add' ?>" class="btn btn-success m-1"> <i class="fa fa-plus"></i> <span>Add <?php echo $page_nm; ?> </span> </a>
        <?php } ?>
     </div>
    </div>
  </div>
<?php if (@$_REQUEST['mode'] != '') { ?>
<section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title2">Manage <?php echo $page_nm; ?><hr></h5>
                <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
            <input type="hidden" name="id" id="id" value="<?php echo @$_REQUEST['id']; ?>" />

                <div class="col-md-6">
                  <label for="inputName5" class="form-label">Office Name</label>
                  <input type="text" class="form-control"id="office_name" name="office_name" value="<?php echo $row[0]->office_name; ?>">
                </div>

                <div class="col-md-6">
                  <label for="inputName5" class="form-label">Status</label>
                 <select name="status" id="status" class="form-select" required> 
                        <option value="">Select Status</option>

                        <option value="Active"<?php if($row[0]->status == 'Active'){ ?> selected="selected" <?php } ?>>Active</option>

                        <option value="Deavtive"<?php if($row[0]->status == 'Deavtive'){ ?> selected="selected" <?php } ?>>Deavtive</option>

                      </select>
                </div>
               
                <div class="text-end">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php } else { ?>
   <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-table"></i> List Of <?php echo $page_nm; ?></h5>

              <!-- Table with stripped rows -->
              <table class="table table-responsive">
                <thead class="text-center">
                  <tr>  
                    <th scope="col">Office Name</th>
                    <th scope="col">Status</th>
                    <th scope="col">Last update</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody class="text-center">
        <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
        ?>
                  <tr>
                    <td><?php echo $row->office_name;?></td>
                    <td><?php echo $row->status;?></td>
                    <td><?php echo date("d-m-Y g:i A", strtotime($row->last_update));?></td>
                      <td>
                          <a href="<?php echo $pageUrl."?mode=edit&id=".$row->id.""; ?>" class="btn btn-primary m-1">Edit</a>
                          <a href="<?php echo $pageUrl."?mode=delete&id=".$row->id.""; ?>" class="delete_check btn btn-danger m-1">Delete</a>
                      </td>
                  </tr>
                   <?php }}?>
                </tbody>
              </table>
              <!-- End Table with stripped rows-->

            </div>
          </div>

        </div>
      </div>
    </section> 
     <?php } ?>

  </main>
  <?php include('footer.php'); ?>