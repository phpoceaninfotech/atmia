<?php
//include('root/config.php');

if($_SESSION['login_type']=="USER")
{
  


?>  

<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-list-ul"></i><span>Manage Student</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <?php 
              /*$admin_qry = "SELECT * FROM tbl_administrator WHERE id=" . $user_id;
              $admin_row = $ai_db->aiGetQueryObj($admin_qry);*/ ?>
            <a href="student.php">
              <i class="bi bi-circle"></i><span>Student</span>
            </a>
            <a href="admission.php">
              <i class="bi bi-circle"></i><span>Admission</span>
            </a>
            <a href="student_fees.php">
              <i class="bi bi-circle"></i><span>Student Fees</span>
            </a>
            <a href="student_profile.php">
              <i class="bi bi-circle"></i><span>Student Profile</span>
            </a>
          </li>
        </ul>
      </li><!-- End Forms Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layers-fill"></i>
            <span>Other</span>
          <i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="manage_country.php">
              <i class="bi bi-circle"></i><span>Manage Country</span>
            </a>
          </li>
          <li>
            <a href="manage_language.php">
              <i class="bi bi-circle"></i><span>Manage  Language</span>
            </a>
          </li>
          <li>
            <a href="manage_office.php">
              <i class="bi bi-circle"></i><span>Manage Office</span>
            </a>
          </li>
          <li>
            <a href="manage_fees_type.php">
              <i class="bi bi-circle"></i><span>Manage Fees</span>
            </a>
          </li>
           <li>
            <a href="manage_terms_cond.php">
              <i class="bi bi-circle"></i><span>Manage Terms Condition</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->
      

      <?php if($_SESSION['login_type']=="ADMIN"){ ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="administrator.php">
          <i class="bi bi-person"></i>
          <span>Administrator</span>
        </a>
      </li>
      <?php } ?>
    </ul>

  </aside><!-- End Sidebar-->

<?php }else{ ?>


<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-list-ul"></i><span>Manage Student</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="student.php">
              <i class="bi bi-circle"></i><span>Student</span>
            </a>
            <a href="admission.php">
              <i class="bi bi-circle"></i><span>Admission</span>
            </a>
            <a href="student_fees.php">
              <i class="bi bi-circle"></i><span>Student Fees</span>
            </a>
            <a href="student_profile.php">
              <i class="bi bi-circle"></i><span>Student Profile</span>
            </a>
          </li>
        </ul>
      </li><!-- End Forms Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layers-fill"></i>
            <span>Other</span>
          <i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="manage_country.php">
              <i class="bi bi-circle"></i><span>Manage Country</span>
            </a>
          </li>
          <li>
            <a href="manage_language.php">
              <i class="bi bi-circle"></i><span>Manage Language</span>
            </a>
          </li>
          <li>
            <a href="manage_office.php">
              <i class="bi bi-circle"></i><span>Manage Office</span>
            </a>
          </li>
          <li>
            <a href="manage_fees_type.php">
              <i class="bi bi-circle"></i><span>Manage Fees</span>
            </a>
          </li>
          <li>
            <a href="manage_terms_cond.php">
              <i class="bi bi-circle"></i><span>Manage Terms Condition</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->
      


   <!--   <li class="nav-item">
        <a class="nav-link collapsed" href="form.php">
          <i class="bi bi-person"></i>
          <span>Admission</span>
        </a>
      </li>  End Profile Page Nav -->
      <?php if($_SESSION['login_type']=="ADMIN"){ ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="administrator.php">
          <i class="bi bi-person"></i>
          <span>Administrator</span>
        </a>
      </li>
      <?php } ?>
    </ul>

  </aside><!-- End Sidebar-->
<?php } ?>