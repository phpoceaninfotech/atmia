<?php include('root/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
      <link href="assets/img/favicon.png" rel="icon">
      <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

      <!-- Google Fonts -->
      <link href="https://fonts.gstatic.com" rel="preconnect">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

      <!-- Vendor CSS Files -->
      <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
      <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
      <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
      <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
      <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
      <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

      <!-- Template Main CSS File -->
      <link href="assets/css/style.css" rel="stylesheet">
  </head>
  <body>
<main id="main2" class="main">
  <div class="row">
    <div class="col-md-10 well">
      <h1 class="" style="color: #012970;">Forex Calculater</h1>
      <hr style="border-top:1px solid; #000;"/>
      <form method="GET" action="" >
      <div class="form-inline">
        <div class="row mb-3">
          <label class="col-sm-3 col-form-label">Indian Rupee : </label>
          <div class="col-sm-9">
             <input class="form-control text-right" type="number" value="<?php echo isset($_GET['txt_digit']) ? $_GET['txt_digit'] : ''  ?>" name="txt_digit"/>
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-3 col-form-label">Select Currency : </label>
          <div class="col-sm-9">
            <select name="currency" class="form-control">
              <option value="">Select an option</option>
              <option value="Dollar" <?php echo isset($_GET['currency']) && $_GET['currency'] == "Dollar" ? 'selected' : ''; ?>>Dollar</option>

              <option value="PESO" <?php echo isset($_GET['currency']) && $_GET['currency'] == "PESO" ? 'selected' : ''; ?>>PESO</option>
            </select>
          </div>
        </div>
        <center>
          <div class="row mb-3">
          <label for="inputEmail3" class="col-sm-3 col-form-label">Convert Amount</label>
          <div class="col-sm-9">
             <?php require 'convert.php'?>
          </div>
      </div>
          <button type="submit" name="btn_submit" class="btn btn-primary form-control" style="width:30%;">Convert</button>
        </center>
      </div>
      </form>
    </div>
  </div>
</main>
</body>
</html>

<?php// include('footer.php'); ?>