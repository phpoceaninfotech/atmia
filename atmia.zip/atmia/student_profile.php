<?php include('root/config.php'); 

$page_nm = "Student Profile";
$pageUrl = "student_profile.php";

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if (@$_GET['mode'] != '') {
$id = (int) @$_REQUEST['id'];
$name = (int) $_REQUEST['name'];

if ($id != '') 
  {     
        $qry = "SELECT * FROM  tbl_student WHERE id=" . $id;
        $rows = $ai_db->aiGetQueryObj($qry);
  }

}
else{
 $qry = "SELECT * FROM  tbl_student ORDER BY name ASC";
 $result = $ai_db->aiGetQueryObj($qry);
}
?>
  
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
<?php include('header.php'); ?>
<main id="main" class="main">
  <?php include('menu.php');?>
  <div class="row">
    <div class="col-sm-12">
      <h4 class="pagetitle">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
  </div>
  <?php if (@$_REQUEST['mode'] != '') { ?>
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title"><?php echo $page_nm; ?><hr></h5>
          <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            
            <input type="hidden" name="id" id="id" value="<?php echo @$_REQUEST['id']; ?>" />
                <div class="col-md-5" style="border-right: 1px solid #bfbfbf;">
                   <h5 class="card-title3">Student Personal Details<hr></h5>
                <dl>
                  <dt>Student Name</dt>
                  <dd>- <?php echo $rows[0]->name; ?></dd>
                  <dt>Father Name</dt>
                  <dd>- <?php echo $rows[0]->fathername; ?></dd>
                  <dt>Profession</dt>
                  <dd>- <?php echo $rows[0]->profession1; ?></dd>
                  <dt>Mother Name</dt>
                  <dd>- <?php echo $rows[0]->mothername; ?></dd>
                  <dt>Profession</dt>
                  <dd>- <?php echo $rows[0]->profession2; ?></dd>
                  <dt>Address</dt>
                  <dd>- <?php echo $rows[0]->address; ?></dd>
                  <dt>Mobile-No</dt>
                  <dd>- <?php echo $rows[0]->primary_no; ?></dd>
                  <dt>Email</dt>
                  <dd>- <?php echo $rows[0]->email; ?></dd>
                </dl>

              </div>
              <div class="col-md-7">
               <h5 class="card-title3">Aduction details<hr></h5>
                <table class="table table-sm table-bordered table-bordered">
                <thead class="text-center">
                  <tr>
                    <th scope="col">Class</th>
                    <th scope="col">School</th>
                    <th scope="col">Board</th>
                    <th scope="col">Result</th>
                  </tr>
                </thead>
                <tbody class="text-center">
<?php             
$sch_qry = "SELECT * FROM  `tbl_school_&_result` WHERE student_id='".$id."'";
$sch_result = $ai_db->aiGetQueryObj($sch_qry);
if (COUNT($sch_result) > 0) {
foreach ($sch_result as $sch_row) {
?>
                  <tr>
                    <td><?php echo $sch_row->class;  ?></td>
                    <td><?php echo $sch_row->school; ?></td>
                    <td><?php echo $sch_row->board;  ?></td>
                    <td><?php echo $sch_row->result; ?></td>
                  </tr>
<?php } } ?>
                </tbody>
              </table>
                <h5 class="card-title3">Student fees<hr></h5>
                <table class="table table-sm table-bordered table-responsive">
                <thead class="text-center">
                  <tr>
                    <th scope="col">SR.No</th>
                    <th scope="col">Payment</th>
                    <th scope="col">Description</th>
                   
                  </tr>
                </thead>
                <tbody class="text-center">
<?php   
$fees_qry = "SELECT * FROM  tbl_fees_details WHERE student_fees_id='".$name."'";

$fees_result = $ai_db->aiGetQueryObj($fees_qry);
if (COUNT($fees_result) > 0) {
foreach ($fees_result as $fees_row) {
?>
                  <tr>
                    <?php $i=1; ?>
                    <td><?php echo $i;?></td>
                    <td><?php echo $fees_row->new_fees;?></td>
                    <td><?php echo $fees_row->description;?></td>
                    <!-- <td><a href="" class="btn btn-success">Recipt</a></td> -->
                    <?php $i++; ?>
                  </tr>
<?php } } ?>
                <tr class="text-end">
                  <th></th>
                  <th></th>
                  <th><a href="" class="btn btn-success">Recipt</a></th>
                </tr>

                </tbody>
              </table>
              </div>
                <div class="text-end">
                  <button type="submit" class="btn btn-success"><i class="bi bi-plus-circle"></i> Issuu</button>
                  <button type="reset" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Clear</button>
                </div>
              </form>
        </div>
      </div>
    </div>
  </section>
<?php }else {?>
   <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-table"></i> List Of <?php echo $page_nm; ?></h5>

              <!-- Table with stripped rows -->
              <table class="table datatable table-responsive">
                <thead>
                  <tr>
                    <th scope="col">Student Name</th>
                    <th scope="col">Last update</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
          <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
          ?>
                  <tr>
                    <td><?php echo $row->name;?></td>
                    <td><?php echo date("d-m-Y g:i A", strtotime($row->last_update));?></td>
                    <td>
                        <a href="<?php echo $pageUrl."?mode=view&id=".$row->id.""; ?>" class="btn btn-primary m-1">View <?php echo $page_nm; ?></a>
                    </td>
                  </tr>
                  <?php }} ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows-->

            </div>
          </div>

        </div>
      </div>
    </section> 
   <?php } ?>
</main>
<?php include('footer.php')?>
