<?php
include('root/config.php');


$page_nm = "Administrator";
$pageUrl = "administrator.php";

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if (isset($_POST['btn_submit'])) {
    $authorityname = $_POST['authorityname'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $status = $_POST['status'];
   $add_qry = "INSERT INTO tbl_administrator SET 
           authorityname='".$authorityname."',
           name='".$name."',
           email='".$email."',
           mobile='".$mobile."',
           username='".$username."',
           password='".$password."',
           status='".$status."'";     
          $ai_db->aiQuery($add_qry);
        $ai_core->aiGoPage($pageUrl );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<div class="pt-sm-3 align-items-center">
      <div class="mx-auto col-10 col-md-8 col-lg-4">
        <div class="card">
          <div class="card-body">
            <div class="text-center">
              <img src="assets/img/ATMIA EDUCATION.png" alt="logo icon" 
              style="padding-top:20px;width: 180px;">
             </div>
            <h5 class="card-title text-center">Administrator Login</h5>

              <!-- Vertical Form -->
           <form class="row g-2"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="id" id="id" value="<?php echo @$_REQUEST['id']; ?>" />
              <div class="col-12">
                  <select class="form-select" name="authorityname">
                     <option value="">Select Administrator</option>
                     <option value="Super Admin">Super Admin</option>
                     <option value="supervisor">supervisor</option>
                     <option value="Office Head">Office Head</option>
                     <option value="Staff">Staff</option>
                   </select>
                </div>
              <div class="col-12 ">
                  <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name">
              </div>
              <div class="col-12 ">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email Address">
              </div>
              <div class="col-12 ">
                  <input type="text" class="form-control" name="mobile" id="mobile" placeholder="Enter Contact-No">
              </div>
              <div class="col-12 ">
                  <input type="text" class="form-control" name="username" id="username" placeholder="Enter User Name">
              </div>
              <div class="col-12">
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password">
              </div>
              <div class="col-12">
                  <select class="form-select" name="status" id="status">
                     <option value="">Select Status</option>
                     <option value="Active">Active</option>
                     <option value="Deavtive">Deavtive</option>
                   </select>
                </div>
              <div class="text-center ">
                <button type="submit" name="btn_submit" id="btn_submit" class="btn col-lg-12 btn-primary">Submit</button>
              </div>
            </form><!-- Vertical Form -->
          </div>
        </div>
      </div>
    </div>



<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>

</html>


