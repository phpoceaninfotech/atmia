<?php
include('root/config.php');

$page_nm = "Administrator";
$pageUrl = "administrator.php";

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if ($_GET['mode'] != '') {
$id = (int) $_REQUEST['id'];

if (isset($_POST['btn_submit'])) {

$office_id = $_POST['office_id'];
$authority_id = $_POST['authority_id'];
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$username = $_POST['username'];
$password = $_POST['password'];
$passmd5 = md5($password);
$status = $_POST['status'];




    //add record
        if ($_POST['id'] == '' && $_POST['mode'] == 'add') {
          $add_qry = "INSERT INTO tbl_administrator SET 
           office_id='".$office_id."',
           authority_id='".$authority_id."',
           name='".$name."',
           email='".$email."',
           mobile='".$mobile."',
           username='".$username."',
           password='".$password."',
           passmd5='".$passmd5."',
           status='".$status."'";     
           $ai_db->aiQuery($add_qry);
          
            $administrator_id = $ai_db->aiLastInsert();

            mysqli_query($ai_conn, "INSERT INTO tbl_menu (administrator_id, file_name)
            VALUES ('$administrator_id', 'student'),('$administrator_id', 'admission'),('$administrator_id', 'student_fees'),('$administrator_id', 'student_profile'),('$administrator_id', 'manage_country'),('$administrator_id', 'manage_language')");

            $ai_core->aiGoPage($pageUrl . "?msg=1");
          
        }
    //edit record
    if ($_POST['id'] != '' && $_POST['mode'] == 'edit') {
            $editqry = "UPDATE tbl_administrator SET 
            office_id='".$office_id."',
            authority_id='".$authority_id."',
            name='".$name."',
           email='".$email."',
           mobile='".$mobile."',
           username='".$username."',
           password='".$password."',
           passmd5='".$passmd5."',
           status='".$status."' WHERE id=" . $id;
           
            $ai_db->aiQuery($editqry);
      
      $ai_core->aiGoPage($pageUrl . "?msg=2");
        }
    }

    if (isset($_POST['btn_submitmeun'])) {
      $menuid = COUNT($_POST['menuid']);
      for ($i=0; $i < $menuid ; $i++) { 
        $menu_id = $_POST['menuid'][$i];
        $view_status = $_POST['view_status'][$i];
        $add_status = $_POST['add_status'][$i];
        $edit_status = $_POST['edit_status'][$i];

        $meuneditqry = "UPDATE tbl_menu SET 
            view_status='".$view_status."',
            add_status='".$add_status."',
           edit_status='".$edit_status."' WHERE id=" . $menu_id;
           
            $ai_db->aiQuery($meuneditqry);

      }

      $ai_core->aiGoPage($pageUrl . "?msg=2");
    }

  //delete record
    if ($_GET['mode'] == 'delete' && $id != '') 
  {
    
    $qry_del_su = "Delete from tbl_administrator WHERE id=".$id;
        $ai_db->aiQuery($qry_del_su);
    $qry_del_menu = "Delete from tbl_menu WHERE administrator_id=".$id;
        $ai_db->aiQuery($qry_del_menu);    
    
    $ai_core->aiGoPage($pageUrl . "?msg=3");
    }
  //get data for edit
  if ($id != '') 
  {
        $qry = "SELECT * FROM tbl_administrator WHERE id=" . $id;
        $row = $ai_db->aiGetQueryObj($qry);
  }
} 
else{
  //select all record
   $qry = "SELECT * FROM tbl_administrator ORDER BY id DESC";
    $result = $ai_db->aiGetQueryObj($qry);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?>  </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<?php include('header.php'); ?>


<main id="main" class="main">
  <div class="row pt-2 pb-2">
    <?php include('menu.php');?>
    <div class="col-sm-9">
      <h4 class="pagetitle">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
 
  <div class="col-sm-3">
     <div class="float-sm-right">
      <?php if($_REQUEST['mode'] != 'add'){ ?>
        <a href="<?php echo $pageUrl .'?mode=add' ?>" class="btn btn-success m-1"> <i class="fa fa-plus"></i> <span>Add <?php echo $page_nm; ?></span> </a>
        <?php } ?>
     </div>
    </div>
  </div>
  <?php if ($_REQUEST['mode'] != '') { ?>
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <?php if($_REQUEST['mode'] == 'meun'){ ?>
              <h5 class="card-title">
              Admission Meun<hr>
            </h5>
            <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
              <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
              <input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>" />
            <div class="col-md-12">
              <?php
            $qrys = "SELECT * FROM ".DB_PREFIX."menu WHERE administrator_id='".$_REQUEST['id']."' ORDER BY id ASC";
            $rows = $ai_db->aiGetQueryObj($qrys);
            foreach($rows as $mcrow){
            ?>

              <input type="hidden" name="menuid[]" id="menuid" value="<?php echo $mcrow->id; ?>" />
              <div class="row" style="border-bottom: solid 1px #000; padding-bottom: 14px; margin-bottom: 10px;">
                <h4 style="font-weight: 700; color: #0082c9;text-transform: capitalize;"><?php echo str_replace('_', ' ', $mcrow->file_name); ?></h4>
                <div class="col-md-4">
                  <label for="inputview_status" class="form-label">Select View Status</label>
                  <select class="form-select" name="view_status[]" id="inputview_status" data-parsley-required="true">
                     <!-- <option value="">Select Status</option> -->
                     <option <?php if($mcrow->view_status == '1'){ echo 'selected'; } ?> value="1">Deactivate</option>
                     <option <?php if($mcrow->view_status == '0'){ echo 'selected'; } ?> value="0">Active</option>
                     
                   </select>
                </div>
                <div class="col-md-4">
                  <label for="inputadd_status" class="form-label">Select Add Status</label>
                  <select class="form-select" name="add_status[]" id="inputadd_status" data-parsley-required="true">
                     <!-- <option value="">Select Status</option> -->
                     <option <?php if($mcrow->add_status == '1'){ echo 'selected'; } ?> value="1">Deactivate</option>
                     <option <?php if($mcrow->add_status == '0'){ echo 'selected'; } ?> value="0">Active</option>
                     
                   </select>
                </div>
                <div class="col-md-4">
                  <label for="inputedit_status" class="form-label">Select Edit Status</label>
                  <select class="form-select" name="edit_status[]" id="inputedit_status" data-parsley-required="true">
                     <!-- <option value="">Select Status</option> -->
                     <option <?php if($mcrow->edit_status == '1'){ echo 'selected'; } ?> value="1">Deactivate</option>
                     <option <?php if($mcrow->edit_status == '0'){ echo 'selected'; } ?> value="0">Active</option>
                     
                   </select>
                </div>
              </div>  
              <?php } ?>  
              </div>
                <div class="text-end">
                  <button type="submit" name="btn_submitmeun" id="btn_submitmeun" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
              </form>

            <?php }else{ ?>
            <h5 class="card-title">
              Admission<hr>
            </h5>
            <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
            <input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>" />
            
            <div class="col-md-6">
                  <label for="inputoffice_id" class="form-label">Office</label>
                 <select class="form-select" name="office_id" id="inputoffice_id" data-parsley-required="true">
                      <option value="">Select Office</option>
            <?php
            $qrys = "SELECT * FROM ".DB_PREFIX."Office WHERE status='Active' ORDER BY id ASC";
            $rows = $ai_db->aiGetQueryObj($qrys);
            foreach($rows as $mcrow){
            ?>
            <option <?php if($row[0]->office_id == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->id; ?>"><?php echo $mcrow->office_name; ?></option>
            <?php } ?>
                     </select>
                </div>

              <div class="col-md-6">
                  <label for="inputauthority_id" class="form-label">Administrator</label>
                 <select class="form-select" name="authority_id" id="inputauthority_id" data-parsley-required="true">
                      <option value="">Select Administrator</option>
            <?php
            $qrys = "SELECT * FROM ".DB_PREFIX."administrator_type WHERE status='Active' ORDER BY id ASC";
            $rows = $ai_db->aiGetQueryObj($qrys);
            foreach($rows as $mcrow){
            ?>
            <option <?php if($row[0]->authority_id == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->id; ?>"><?php echo $mcrow->name; ?></option>
            <?php } ?>
                     </select>
                </div>

                <div class="col-md-6">
                  <label for="inputname" class="form-label">Name</label>
                  <input type="text" class="form-control" name="name" id="inputname" placeholder="Enter Name" value="<?php echo $row[0]->name; ?>" data-parsley-required="true">
                </div>

                <div class="col-md-6">
                  <label for="inputemail" class="form-label">Email</label>
                  <input type="email" class="form-control" name="email" id="inputemail" placeholder="Enter Email Address" value="<?php echo $row[0]->email; ?>" data-parsley-required="true">
                </div>

                <div class="col-md-6">
                  <label for="inputmobile" class="form-label">Contact No.</label>
                  <input type="text" class="form-control" name="mobile" id="inputmobile" placeholder="Enter Contact No." value="<?php echo $row[0]->mobile; ?>" data-parsley-required="true">
                </div>
                <div class="col-md-6">
                  <label for="inputusername" class="form-label">User Name</label>
                  <input type="text" class="form-control" name="username" id="inputusername" placeholder="Enter User Name" value="<?php echo $row[0]->username; ?>" data-parsley-required="true">
                </div>
                <div class="col-md-6">
                  <label for="inputpassword" class="form-label">Password</label>
                  <input type="text" class="form-control" name="password" id="inputpassword" placeholder="Enter Password" value="<?php echo $row[0]->password; ?>" data-parsley-required="true">
                </div>
                
                <div class="col-md-6">
                  <label for="inputstatus" class="form-label">Select Status</label>
                  <select class="form-select" name="status" id="inputstatus" data-parsley-required="true">
                     <!-- <option value="">Select Status</option> -->
                     <option <?php if($row[0]->status == 'Deavtive'){ echo 'selected'; } ?> value="Deavtive">Deavtive</option>
                     <option <?php if($row[0]->status == 'Active'){ echo 'selected'; } ?> value="Active">Active</option>
                     
                   </select>
                </div>


                <div class="text-end">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
              </form> 
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } else { ?>
 <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-table"></i> List Of <?php echo $page_nm; ?></h5>

              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead class="text-center">
                  <tr>  
                    <th scope="col">Office</th>
                    <th scope="col">Administrator</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact No.</th>
                    <th scope="col">User Name</th>
                    <th scope="col">Password</th>
                    <th scope="col">Meun Status</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
        ?>
                  <tr>
                    <td><?php echo $ai_core->aiGetValue(DB_PREFIX."office","office_name","id",$row->office_id);?></td>
                    <td><?php echo $ai_core->aiGetValue(DB_PREFIX."administrator_type","name","id",$row->authority_id);?></td>
                    <td><?php echo $row->name;?></td>
                    <td><?php echo $row->email;?></td>
                    <td><?php echo $row->mobile;?></td>
                    <td><?php echo $row->username;?></td>
                    <td><?php echo $row->password;?></td>

                    <td><a href="<?php echo $pageUrl."?mode=meun&id=".$row->id.""; ?>" class="btn btn-info m-1"> Roles </a></td>

                    <td><?php echo $row->status;?></td>
                   <td>
                        <a href="<?php echo $pageUrl."?mode=edit&id=".$row->id.""; ?>" class="btn btn-primary m-1">Edit</a>
                        <a href="<?php echo $pageUrl."?mode=delete&id=".$row->id.""; ?>" class="delete_check btn btn-danger m-1">Delete</a>
                    </td>
                  </tr>
                   <?php }}?>
                </tbody>
              </table>
              <!-- End Table with stripped rows-->

            </div>
          </div>

        </div>
      </div>
    </section> 
     <?php } ?>
</main>


<?php include('footer.php'); ?>


<!-- <script>
    $(document).ready(function () {
        $("#inputview_status").change(function () {
            var viewstatus = $(this).val();
            if(viewstatus=='Active'){
              $("#inputadd_status").prop('disabled', false);
              $("#inputedit_status").prop('disabled', false);
            }else{
              $("#inputedit_status").prop('disabled', true);
              $("#inputadd_status").prop('disabled', true);
            }
        });
    });    
</script> -->