<?php include('header.php'); ?>
<?php
include('root/config.php');

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
$pageUrl = "student_fees.php";


 $qry = "SELECT stf.*,st.address FROM  tbl_student_fees stf,tbl_student st WHERE stf.name=st.name ORDER BY name ASC";
    $result = $ai_db->aiGetQueryObj($qry);

?>
  <!-- ======= Sidebar ======= -->
  <?php include('menu.php');?>
  <main id="main" class="main">

    <section class="section dashboard">
      <div class="row"> 


        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body2">
                  <h5 class="card-title">Student <span>| Today</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6>145</h6>
                      <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">Student</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->
        
            <div class="col-xxl-4 col-md-6">
          <div class="">
            
            <?php if($_REQUEST['mode'] != 'add'){ ?>
        <a href="<?php echo $pageUrl .'?mode=add' ?>" class="btn btn-success m-1 float-sm-end" style="width:200px"><i class="fa fa-plus"></i> <span>Add Payment</span></a>
        <?php } ?>
          </div>
        </div><!-- End Button -->
            

            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Recent Student <span>| Today</span></h5>

                  <table class="table table-borderless datatable">
                    <thead class="text-center">
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">Student Name</th>
                        <th scope="col">City</th>
                        <th scope="col">fees</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody class="text-center">
        <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
        ?>
                      <tr>
                        <td scope="row"><?php echo $row->id;?></td>
                        <td><?php echo $row->name;?></td>
                        <td><?php echo $row->address;?></td>
                        <td><?php echo $row->totalfees;?></td>
                        <td><span class="badge bg-success">Complet</span></td>
                      </tr>
        <?php }} ?>
                    </tbody>
                  </table>
                </div>

              </div>
            </div><!-- End Recent Sales -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
<?php include('footer.php'); ?>