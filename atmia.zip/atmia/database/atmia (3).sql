-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2023 at 01:31 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atmia`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `is_active` char(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `view_status` varchar(200) NOT NULL DEFAULT 'Active',
  `add_status` varchar(200) NOT NULL DEFAULT 'Active',
  `edit_status` varchar(200) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `email`, `password`, `is_active`, `created_at`, `modified_at`, `view_status`, `add_status`, `edit_status`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '1', '2018-12-29 06:40:08', '2023-07-21 10:11:12', 'Active', 'Active', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_administrator`
--

CREATE TABLE `tbl_administrator` (
  `id` int(11) NOT NULL,
  `authority_id` longtext NOT NULL,
  `name` longtext NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `username` longtext NOT NULL,
  `password` text NOT NULL,
  `passmd5` longtext NOT NULL,
  `status` varchar(20) NOT NULL,
  `view_status` varchar(200) NOT NULL DEFAULT 'Deavtive',
  `add_status` varchar(200) NOT NULL DEFAULT 'Deavtive',
  `edit_status` varchar(200) NOT NULL DEFAULT 'Deavtive',
  `office_id` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_administrator`
--

INSERT INTO `tbl_administrator` (`id`, `authority_id`, `name`, `email`, `mobile`, `username`, `password`, `passmd5`, `status`, `view_status`, `add_status`, `edit_status`, `office_id`) VALUES
(10, '1', 'test', 'demo@gmail.com', '1234567890', 'demo', 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'Active', 'Deavtive', 'Deavtive', 'Deavtive', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_administrator_type`
--

CREATE TABLE `tbl_administrator_type` (
  `id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `status` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_administrator_type`
--

INSERT INTO `tbl_administrator_type` (`id`, `name`, `status`) VALUES
(1, 'Super Admin', 'Active'),
(2, 'supervisor', 'Active'),
(3, 'Office Head', 'Active'),
(4, 'Staff', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admission`
--

CREATE TABLE `tbl_admission` (
  `id` int(11) NOT NULL,
  `country` longtext NOT NULL,
  `language` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admission`
--

INSERT INTO `tbl_admission` (`id`, `country`, `language`, `last_update`) VALUES
(4, 'Canada', 'english', '2023-07-19 07:50:20'),
(5, 'Australia', 'Bengali', '2023-07-19 08:28:32'),
(6, 'India', 'Bengali', '2023-07-21 05:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `id` int(11) NOT NULL,
  `countryname` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`id`, `countryname`, `last_update`, `status`) VALUES
(2, 'india ', '2023-07-22 06:35:07', 'Active'),
(3, 'Australia', '2023-07-22 06:35:18', 'Active'),
(4, 'Canada', '2023-07-22 06:35:12', 'Active'),
(5, 'india 2', '2023-07-22 06:35:01', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fees_details`
--

CREATE TABLE `tbl_fees_details` (
  `student_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `student_fees_id` int(11) NOT NULL,
  `new_fees` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_fees_details`
--

INSERT INTO `tbl_fees_details` (`student_id`, `id`, `student_fees_id`, `new_fees`, `description`, `last_update`) VALUES
(0, 22, 9, 1000, 'Admisssion Fees', '2023-08-03 10:40:47'),
(0, 23, 9, 1000, 'Hostel Fees', '2023-08-03 10:40:47'),
(0, 24, 9, 1000, 'Tution Fees', '2023-08-03 10:40:47'),
(22, 25, 10, 11000, 'Admisssion Fees', '2023-08-03 10:41:57'),
(22, 26, 11, 1000, 'Tution Fees', '2023-08-03 10:42:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fees_type`
--

CREATE TABLE `tbl_fees_type` (
  `id` int(11) NOT NULL,
  `fees_name` longtext NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_fees_type`
--

INSERT INTO `tbl_fees_type` (`id`, `fees_name`, `status`, `last_update`) VALUES
(1, 'Admisssion Fees', 'Active', '2023-08-01 05:00:50'),
(2, 'Tution Fees', 'Active', '2023-08-01 05:00:18'),
(3, 'Hostel Fees', 'Active', '2023-08-01 05:00:37');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `id` int(11) NOT NULL,
  `language` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`id`, `language`, `last_update`, `status`) VALUES
(1, 'Gujrati', '2023-07-22 06:40:44', 'Active'),
(2, 'english', '2023-07-22 06:33:47', 'Active'),
(3, 'Hindi', '2023-07-22 06:40:52', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL,
  `administrator_id` int(11) NOT NULL,
  `file_name` longtext NOT NULL,
  `view_status` int(11) NOT NULL DEFAULT 0,
  `add_status` int(11) NOT NULL DEFAULT 0,
  `edit_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `administrator_id`, `file_name`, `view_status`, `add_status`, `edit_status`) VALUES
(13, 10, 'student', 0, 1, 0),
(14, 10, 'admission', 1, 0, 1),
(15, 10, 'student_fees', 0, 1, 0),
(16, 10, 'student_profile', 1, 0, 1),
(17, 10, 'manage_country', 0, 1, 0),
(18, 10, 'manage_language', 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_office`
--

CREATE TABLE `tbl_office` (
  `id` int(11) NOT NULL,
  `office_name` longtext NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_office`
--

INSERT INTO `tbl_office` (`id`, `office_name`, `status`, `last_update`) VALUES
(1, 'atmia 1', 'Active', '2023-07-31 06:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_school_&_result`
--

CREATE TABLE `tbl_school_&_result` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class` longtext NOT NULL,
  `school` longtext NOT NULL,
  `board` longtext NOT NULL,
  `result` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_school_&_result`
--

INSERT INTO `tbl_school_&_result` (`id`, `student_id`, `class`, `school`, `board`, `result`, `last_update`) VALUES
(10, 22, '14', 'test22', 'test 122', '1235', '2023-08-02 12:36:22'),
(11, 22, '15', 'demo 122', 'demo 222', '1236', '2023-08-02 12:36:22'),
(12, 22, '16', 'test1222', 'test 1222', '1233', '2023-08-02 12:36:22'),
(13, 22, '132', 'test22', 'test 122', '123235', '2023-08-02 12:47:06'),
(21, 25, '10', 'test', 'test 1', '70%', '2023-08-03 07:47:35'),
(22, 25, '11', 'demo', 'demo 1', '80%', '2023-08-03 07:47:35'),
(23, 25, '12', 'hello', 'hello 1', '90%', '2023-08-03 07:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `fathername` longtext NOT NULL,
  `profession1` longtext NOT NULL,
  `mothername` longtext NOT NULL,
  `profession2` longtext NOT NULL,
  `primary_no` text NOT NULL,
  `alternate_no` text NOT NULL,
  `email` text NOT NULL,
  `aboutcheck` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `f_no` int(20) NOT NULL,
  `date` date NOT NULL,
  `address` longtext NOT NULL,
  `neetscore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `name`, `fathername`, `profession1`, `mothername`, `profession2`, `primary_no`, `alternate_no`, `email`, `aboutcheck`, `last_update`, `f_no`, `date`, `address`, `neetscore`) VALUES
(22, 'hello', 'hello5', 'JOB', 'hello5', 'job', '321321', '232132', 'demo@gmail.com', 'Newspaper,', '2023-08-03 06:42:29', 2, '2023-08-09', 'dghdfgdfgfdg', 123),
(25, 'Yagnikgiri Gausawami', 'dsadsadasadsasa adasda adadada', 'JOB', 'ssssssssseeeee edasdsds adsadasd', 'job', '123456789', '987654321', 'set@gmail.com', 'Newspaper,Televison,', '2023-08-03 07:47:35', 2, '2023-08-16', 'addsadddsadasdasdsaddsa asdadsadasd  dsadsa da ', 90);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_fees`
--

CREATE TABLE `tbl_student_fees` (
  `note` longtext NOT NULL,
  `id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `select_opt` longtext NOT NULL,
  `chque_no` int(11) NOT NULL,
  `upi` int(11) NOT NULL,
  `totalfees` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student_fees`
--

INSERT INTO `tbl_student_fees` (`note`, `id`, `name`, `select_opt`, `chque_no`, `upi`, `totalfees`, `last_update`) VALUES
('fsdffdsfsf', 9, '22', 'Cash', 0, 0, 3000, '2023-08-03 10:40:47'),
('gdggf', 10, '22', 'Cash', 0, 0, 11000, '2023-08-03 10:41:57'),
('sffsdfsdfdsfsd', 11, '25', 'Cash', 0, 0, 1000, '2023-08-03 10:42:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_terms_condition`
--

CREATE TABLE `tbl_terms_condition` (
  `id` int(11) NOT NULL,
  `terms_condition` longtext NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_terms_condition`
--

INSERT INTO `tbl_terms_condition` (`id`, `terms_condition`, `status`, `last_update`) VALUES
(2, '<p><strong>terms &amp; Condition</strong></p>\r\n\r\n<ol>\r\n	<li><em>ALL FEES BEING COLLECTED ARE ON BEHALF OF THE COLLEGE WHICH WILL BE FORWARDED TO RESPECTIVE DEPARTMENT.</em></li>\r\n	<li><em>NO FEES ARE BEING PAID TO ATMIA&nbsp; ADUCTION.</em></li>\r\n	<li><em>THIS IS JUST ACKNOWLEDGEMENT/VOUCHER FOR THE REFERENCE.</em></li>\r\n	<li><em>OFFICIAL RECIEPT WILL BE ISSUED AND COLLECTED FROM THE COLLEGE.</em></li>\r\n	<li><em>NOT VALID WITH OUT SIGN AND STAMP.</em></li>\r\n</ol>\r\n', 'Active', '2023-08-03 05:59:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_administrator_type`
--
ALTER TABLE `tbl_administrator_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admission`
--
ALTER TABLE `tbl_admission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fees_details`
--
ALTER TABLE `tbl_fees_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fees_type`
--
ALTER TABLE `tbl_fees_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_office`
--
ALTER TABLE `tbl_office`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_school_&_result`
--
ALTER TABLE `tbl_school_&_result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student_fees`
--
ALTER TABLE `tbl_student_fees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_terms_condition`
--
ALTER TABLE `tbl_terms_condition`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_administrator_type`
--
ALTER TABLE `tbl_administrator_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admission`
--
ALTER TABLE `tbl_admission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_fees_details`
--
ALTER TABLE `tbl_fees_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_fees_type`
--
ALTER TABLE `tbl_fees_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_office`
--
ALTER TABLE `tbl_office`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_school_&_result`
--
ALTER TABLE `tbl_school_&_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_student_fees`
--
ALTER TABLE `tbl_student_fees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_terms_condition`
--
ALTER TABLE `tbl_terms_condition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
