   <!-- student.php -->

   <!--  <div class="col-md-8 mt-md-0 mt-3">
                       <div class="row mb-3 my-0">
                        <label for="inputEmail3" class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                          <input type="date" class="form-control" id="inputText">
                        </div>
                      </div> 
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-3 col-form-label">full Name</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control pb-5" id="inputText">
                  </div>
                </div>
                  </div>
                  <div class="col-md-1 mt-md-0 mt-3">

                  </div>
                   <div class="col-md-4 mt-md-0 mt-3">
                      <div class="row mb-3 my-0">
                        <label for="inputEmail3" class="col-sm-4 col-form-label">
                        Form No</label>
                        <div class="col-sm-8">
                          <input type="number" class="form-control" id="inputText">
                        </div>
                      </div>
                      <div class="row mb-3 my-0">
                        <label for="inputEmail3" class="col-sm-4 col-form-label">Date</label>
                        <div class="col-sm-8">
                          <input type="date" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
              </div>

               student Form 
              <form class="">
                 <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">full Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputText">
                  </div>
                </div> 
                <div class="row mb-3">
                  <div class="col-md-8 mt-md-0 mt-3">
                      <div class="row mb-3 my-3">
                        <label for="inputEmail3" class="col-sm-3 col-form-label">
                        Father Name</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
                  <div class="col-md-4 mt-md-0 mt-3">
                      <div class="row mb-3 my-3">
                        <label for="inputEmail3" class="col-sm-4 col-form-label">
                        Profession</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-8 mt-md-0 mt-3">
                      <div class="row mb-3">
                        <label for="inputEmail3" class="col-sm-3 col-form-label">
                        Mother Name</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
                  <div class="col-md-4 mt-md-0 mt-3">
                      <div class="row mb-3">
                        <label for="inputEmail3" class="col-sm-4 col-form-label">
                          Profession</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">Address</label>
                  <div class="col-sm-10">
                    <textarea type="text" class="form-control" id="inputPassword"></textarea>
                  </div>
                </div>
                <div class="row mb-3 my-4">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">City</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control">
                  </div>
                </div>
                <!-- start table form 
                <div class="row">
                  <div class="card">
                    <div class="card-body2">
                      <li class="my-3">Details Of Your School And Result</li>
                      <div class="table-responsive">
                        <style type="text/css">
                          .table {
                            border: 1px solid #0099cc;
                          }
                          .table th{
                            background-color: #0099cc;
                            color: #ffffff;
                          }
                          .table   a {
                            color: #ffffff;
                          
                          }
                        </style>
                        <table class="table text-center" style="">
                            <thead>
                                <tr>
                                  <th scope="col">Class</th>
                                  <th scope="col">School</th>
                                  <th scope="col">Bord</th>
                                  <th scope="col">Result</th>
                                  <th scope="col"><a class="btn" id="insertRow" href="#"><i class="bi bi-plus"></i></a></th>
                                </tr>
                            </thead>
                            <tbody >
                                  
                            </tbody>
                        </table>
                    </div>
                    <!-- Add rows button                    <!-- <a class="btn btn-primary rounded-0 btn-block" id="insertRow" href="#">+</a> 
                </div>
              </div>
              <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">Neet Score</label>
                  <div class="col-sm-5">
                    <input type="text" class="form-control" id="inputPassword">
                  </div>
                </div>
                <!-- End table 

                <!-- start contact form
              <div class="row">
                  <div class="card">
                    <div class="card-body2">
                      <li class="my-3">Contact Information</li>
                       <div class="row mb-3">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Primary
                        </label>
                        <div class="col-sm-5">
                          <input type="number" class="form-control" id="inputPassword">
                        </div>
                      </div>
                       <div class="row mb-3">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Alternate
                        </label>
                        <div class="col-sm-5">
                          <input type="number" class="form-control" id="inputPassword">
                        </div>
                      </div>
                       <div class="row mb-3">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Email ID
                        </label>
                        <div class="col-sm-5">
                          <input type="email" class="form-control" id="inputPassword">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- End contact form  

                <!-- about us form 
                <div class="row">
                  <div class="card">
                    <div class="card-body2">
                      <li class="my-2">How Did You Come To Know About Atmia Education</li>
                      <div class="ps-sm-5">
                        <div class="ps-sm-5 form-check form-check-inline m->">
                        <input class="form-check-input" type="checkbox" name="newspaper"
                               id="disabledRadioSwitch" >
                        <label class="col-sm-2col-form-label" for="disabledRadioSwitch">Newspaper
                          </label>
                        </div>
                        <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="televison"
                                   id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label" for="disabledRadioSwitch">Televison
                              </label>
                        </div>
                        <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="flyers"
                            id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label"for="disabledRadioSwitch">Flyers
                              </label>
                        </div>
                        <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="relatives"
                            id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label"for="disabledRadioSwitch">Relatives
                              </label>
                        </div>
                         <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="friends"
                            id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label"for="disabledRadioSwitch">Friends
                              </label>
                        </div>
                        <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="online"
                            id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label"for="disabledRadioSwitch">Online
                              </label>
                        </div>
                        <div class="form-check form-check-inline m->">
                            <input class="form-check-input" type="checkbox" name="social_media"
                            id="disabledRadioSwitch">
                            <label class="col-sm-2col-form-label" >Social Media
                              </label>
                        </div>
                      </div>
                      <div class="row mb-3 my-3">
                        <label class="col-sm-2 col-form-label">Other</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputPassword">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3 mt-md-0">
                  </div>
                  <div class="col-md-3 mt-md-0">
                  </div>
                   <div class="col-md-6 mt-md-0">
                      <div class="row mb-3">
                        <label for="inputEmail3" class="col-sm-4 col-form-label">
                        Counselor's Name</label>
                        <div class="col-sm-8">
                          <input type="number" class="form-control" id="inputText">
                        </div>
                      </div>
                  </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
                </div>
              </form><!-- End Horizontal Form -->



              <!-- admission.php -->


              <!--            
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Country</label>
                  <div class="col-sm-10">
                     <select class="form-select">
                      <option value="">Selact Country</option>
                       <option value="">India</option>
                       <option value="">Australia</option>
                       <option value="">United States</option>
                       <option value="">Canada</option>
                     </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Language Ecaminaction</label>
                  <div class="col-sm-10">
                     <select class="form-select">
                      <option value="">Selact Language</option>
                       <option value="">english</option>
                       <option value="">Arabic</option>
                       <option value="">Bengali</option>
                       <option value="">French</option>
                     </select>
                  </div>
                </div>
                <div class="text-end">
                  <button type="submit" class="btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
                  <button type="reset" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Clear</button>
                </div>-->


                <!-- student fees.php -->
                <!-- <form class="row g-3">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Student Name</label>
                  <div class="col-sm-8">
                     <select class="form-select">
                      <option value="">Selact Student Name</option>
                       <option value="">name 1</option>
                       <option value="">name 2</option>
                       <option value="">name 3</option>
                       <option value="">name 4</option>
                     </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Fees Description</label>
                  <div class="col-sm-5">
                    <input type="number" class="form-control"  name="oldfee" placeholder="Old Fees"> 
                  </div>
                  <div class="col-sm-5">
                    <input type="number" class="form-control" name="newfee" placeholder="New Fees">
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Fees </label>
                  <div class="col-sm-8">
                    <input type="number" class="form-control"  name="oldfee" placeholder="Total Fees"> 
                  </div>
                  <div class="col-sm-2">
                    <a   href=""  onclick="myFunction()" class=" btn btn-primary">Calculator</a>
                  </div>
                </div>
                <div class="row mb-3">
                   <label for="inputEmail3" class="col-sm-2 col-form-label">Payment Method</label>
                   <div class="col-sm-10">
                    <select name="select_opt" id="select_opt" class="form-select" onchange="showfield(this.options[this.selectedIndex].value)" required> 
                        <option value="">Please Payment Method</option>  
                        <option value="Cash">Cash payment</option>
                        <option value="Cheque">Cheque</option>
                        <option value="Online">Online payment</option>
                      </select>
                    </div>
                  <div class="row mb-3 my-4" id="div1"></div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Fees Amount</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control"  name="amount" placeholder="Total Fees Amount"> 
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Description Note</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control"  name="oldfee" placeholder="Description Note"> 
                  </div>
                </div>
                <div class="form-group row">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
                </div>
              </form>   -->

<!-- student_profile.php -->

<!--             <form>
              <div class="row">
                  <div class="col-md-8 mt-md-0 mt-3">
                    <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-3 col-form-label">Student Name </label>
                <div class="col-sm-9">
                  <select class="form-select">
                      <option value="">Selact Student Name</option>
                       <option value="">name 1</option>
                       <option value="">name 2</option>
                       <option value="">name 3</option>
                       <option value="">name 4</option>
                     </select>
                </div>
              </div>
                  </div>
                   <div class="col-md-4 mt-md-0 mt-3">
                      <div class="row mb-3">
                        <label for="inputEmail3" class="col-sm-5 col-form-label">
                        pending fees :</label>
                        <div class="col-sm-7">
                           <label for="inputEmail3" class="col-form-label">
                            1,50,000</label>
                        </div>
                      </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Father Name : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">Nathabhai asdasdsaasddas
                      </label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Address : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">mavdi road , rajkot 
                      </label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">city : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">rajkot</label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile-No : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">+91 0123456789</label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Email : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">demo@123Gmail.com</label>
                    </div>
                  </div>
                  <h5 class="card-title">Student fees<hr></h5>
                  <div class="card-body">
                    <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Tuition Fees : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">2,00,000</label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">University Fee : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">---</label>
                    </div>
                  </div>
                   <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Security Deposit : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">5,000</label>
                    </div>
                  </div>
                   <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Application Fees : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">1,000</label>
                    </div>
                  </div>
                  <hr class="col-sm-4">
                   <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Total Fees :</label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">2,06,000</label>
                    </div>
                  </div>
                  </div>
                  <h5 class="card-title">Student fees<hr></h5>
                  <div class="card-body">
                     <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Payable Fees : </label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">56,000
                      </label>
                    </div>
                  </div>
                  <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">pending fees :</label>
                    <div class="col-sm-10">
                      <label for="inputEmail3" class="col-form-label">1,50,000</label>
                    </div>
                  </div>
                  <div class="form-group row">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="bi bi-plus-circle"></i> Issuu </button>
                  <a href="" class="btn btn-warning"><i class="bi bi-dash-circle"></i> clear </a>
                </div>
                </div>
              </div>
            </form> -->


<!-- profile.php -->
 <!-- <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">User Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputText">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control" id="inputEmail">
                  </div>
                </div>

                <hr>

                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">New Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">Confirm Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword">
                  </div>
                </div>

                 <div class="form-group row">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                  <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="bi bi-plus-circle"></i> Submit</button>
                  <a href="" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
                </div>
                </div>
              </form> --><!-- End Horizontal Form -->
