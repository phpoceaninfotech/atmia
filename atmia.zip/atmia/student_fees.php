<?php
include('root/config.php');

$page_nm = "Student Fees";
$pageUrl = "student_fees.php";

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if ($_GET['mode'] != '') {
$id = (int) $_REQUEST['id'];

if (isset($_POST['btn_submit'])) {

$name = $_POST['name'];
$select_opt = $_POST['select_opt'];
$chque_no = $_POST['chque_no'];
$upi = $_POST['upi'];
$totalfees = $_POST['totalfees'];
$note = $_POST['note'];


    //add record
        if ($_POST['id'] == '' && $_POST['mode'] == 'add') {
                
      $add_qry = "INSERT INTO  tbl_student_fees SET 
           name='".$name."',
           select_opt='".$select_opt."',
           chque_no='".$chque_no."',
           upi='".$upi."',
           totalfees='".$totalfees."',
           note='".$note."'";     
            $ai_db->aiQuery($add_qry);

            $student_fees_id = $ai_db->aiLastInsert();

            if ($student_fees_id != "") {
              $count =count($_POST['new_fees']);
                for ($i=0; $i < $count ; $i++) { 
                  $student_id = $_POST['student_id'][$i];
                  $new_fees = $_POST['new_fees'][$i];
                  $description = $_POST['description'][$i];
                  $fees_qry ="INSERT INTO  `tbl_fees_details` SET 
                               student_fees_id='".$student_fees_id."',
                               student_id='".$student_id."',
                               new_fees='".$new_fees."',
                               description='".$description."'"; 
                               $ai_db->aiQuery($fees_qry);
                }
            }

        $ai_core->aiGoPage($pageUrl . "?msg=1");
    }
    //edit record
    if ($_POST['id'] != '' && $_POST['mode'] == 'edit') {
            $editqry = "UPDATE  tbl_student_fees SET 
            name='".$name."',
           select_opt='".$select_opt."',
           chque_no='".$chque_no."',
           upi='".$upi."',
           totalfees='".$totalfees."',
           note='".$note."' WHERE id=" . $id;
           
            $ai_db->aiQuery($editqry);

                $count =count($_POST['new_fees']);
                for ($i=0; $i < $count ; $i++) { 
                  $fees_id = $_POST['fees_id'][$i];
                  $student_id = $_POST['student_id'][$i];
                  $new_fees = $_POST['new_fees'][$i];
                  $description = $_POST['description'][$i];
                  if ($fees_id == "") {
                    $fees_qry1 ="INSERT INTO  tbl_fees_details SET 
                               student_fees_id='".$id."',
                               student_id='".$student_id."',
                               new_fees='".$new_fees."',
                               description='".$description."'"; 
                               $ai_db->aiQuery($fees_qry1);
                }else{
                    $fees_qry ="UPDATE tbl_fees_details SET 
                               new_fees='".$new_fees."',
                               description='".$description."'WHERE id=" . $fees_id; 
                               $ai_db->aiQuery($fees_qry);
                }

                }
            
      
      $ai_core->aiGoPage($pageUrl . "?msg=2");
        }
    }
  //delete record
    if ($_GET['mode'] == 'delete' && $id != '') 
  {
    
    $qry_del_su = "Delete from  tbl_student_fees WHERE id=".$id;
        $ai_db->aiQuery($qry_del_su);

     $qry_del_fees = "Delete from tbl_fees_details WHERE student_fees_id=".$id;
        $ai_db->aiQuery($qry_del_fees);
    
    $ai_core->aiGoPage($pageUrl . "?msg=3");
    }
  //get data for edit
  if ($id != '') 
  {
        $qry = "SELECT * FROM  tbl_student_fees WHERE id=" . $id;
        $row = $ai_db->aiGetQueryObj($qry);
  }
} 
else{
  //select all record
   $qry = "SELECT * FROM  tbl_student_fees ORDER BY name ASC";
    $result = $ai_db->aiGetQueryObj($qry);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?>  </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
<?php include('header.php'); ?>
<main id="main" class="main">
  <div class="row pt-2 pb-2">
    <?php include('menu.php');?>
    <div class="col-sm-10">
      <h4 class="pagetitle">
       <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
        </ol>
    </div>
 
  <div class="col-sm-2">
     <div class="float-sm-right">
      <?php if($_REQUEST['mode'] != 'add'){ ?>
        <a href="<?php echo $pageUrl .'?mode=add' ?>" class="btn btn-success m-1"> <i class="fa fa-plus"></i> <span>Add fees</span> </a>
        <?php } ?>
     </div>
    </div>
  </div>
  <?php if ($_REQUEST['mode'] != '') { ?>
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">
              Student Fees <hr>
            </h5>
            <form class="row g-3"  name="frm" id="frm"  data-parsley-validate method="POST" saction="" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
            <input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>" />

            <div class="col-md-8 border-end">
              <div class="col-12">
              <label for="inputName5" class="form-label">Student Name</label>
              <select class="form-select" name="name">
                <option value="">Selact Student Name</option>
                  <?php
                    $qrys = "SELECT * FROM tbl_student order by name ASC";
                    $rows = $ai_db->aiGetQueryObj($qrys);
                    foreach($rows as $mcrow){
                    ?>
                    <option <?php if($row[0]->name == $mcrow->id) { ?> selected="selected" <?php  } ?> value="<?php echo $mcrow->id; ?>"><?php echo $mcrow->name; ?></option>
                  <?php } ?>
                </select>
              </div>

              <?php if($_REQUEST['mode'] == 'add'){ ?>

              <div class="field_wrapper col-lg-12">
                  <div class="row">
                  <?php
                  $qry_id = "SELECT * From  tbl_student ORDER BY id ASC";
                  $id_row = $ai_db->aiGetQueryObj($qry_id);
                  //while($mcrow = $id_row->aiFetchArray()){
                  ?>
                  <input type="hidden" name="student_id[]" value="<?php echo $id_row[0]->id; ?>"/>
               <?php //}  ?>
                    <div class="col-md-5">
                       <label for="inputfees5" class="form-label">New Fees</label>
                      <input type="text" name="new_fees[]"  class="form-control" id="inputoldfees5" placeholder="Enetr Amounnt" value="<?php echo $row[0]->new_fees ?>"/>
                    </div>
                    <div class="col-md-5">
                       <label for="inputfees5" class="form-label">Description</label>
                     <select class="form-select" name="description[]">
                        <option value="">Selact Fees Name</option>
                          <?php
                            $qrys = "SELECT * FROM tbl_fees_type WHERE status='active' ORDER BY id ASC";
                            $rows = $ai_db->aiGetQueryObj($qrys);
                            foreach($rows as $mcrow){
                            ?>
                            <option <?php if($row[0]->description == $mcrow->id) { ?> selected="selected"<?php  } ?> value="<?php echo $mcrow->fees_name; ?>"><?php echo $mcrow->fees_name; ?></option>
                          <?php } ?>
                          </select>
                    </div>
                    <div class="col-md-2" style="padding-top: 30px;">
                      <a href="javascript:void(0);" class="add_button btn btn-success" title="Add field"><i class="bi bi-plus-circle"></i></a>
                    </div>
                  </div>
              </div>

            <?php }else{ ?>

              <div class="field_wrapper col-lg-12">
                  <div class="row g-2">
                    <div class="col-md-5">
                       <label for="inputfees5" class="form-label">New Fees</label>
                    </div>
                    <div class="col-md-5">
                       <label for="inputfees5" class="form-label">Description</label>
                     </div>
                    

            <?php   
              $fees_qry = "SELECT * From  tbl_fees_details WHERE student_fees_id='".$id."'";
              $fees_result = $ai_db->aiGetQueryObj($fees_qry);
              if (COUNT($fees_result) > 0) {
            foreach ($fees_result as $fees_row) {
             ?>
              <input type="hidden" name="fees_id[]" value="<?php echo $fees_row->id; ?>">

              <div class="col-md-5">
                <input type="text" name="new_fees[]"  class="form-control" id="inputoldfees5" placeholder="Enetr Amounnt" value="<?php echo $fees_row->new_fees ?>"/>
              </div>
              <div class="col-md-5">
                <select class="form-select" name="description[]">
                  <option value="">Selact Fees Name</option>
                    <?php
                      $qrys = "SELECT * FROM tbl_fees_type WHERE status='active' ORDER BY id ASC";
                      $rows = $ai_db->aiGetQueryObj($qrys);
                      foreach($rows as $mcrow){
                      ?>
                      <option <?php if($fees_row->description == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->fees_name; ?>"><?php echo $mcrow->fees_name; ?></option>
                    <?php } ?>
                    </select>
              </div>
               <div class="col-md-1" style="padding-top: 0px;">
                      <a href="javascript:void(0);" class="add_button btn btn-success" title="Add field"><i class="bi bi-plus-circle"></i></a>
                    </div>

            <?php } } ?>

              </div>
            </div>

            <?php } ?>

              <div class="col-12">
                <label for="inputnote" class="form-label">Notes</label>
                <textarea type="text" name="note" class="form-control" id="inputnote" placeholder="Notes" value=""><?php echo $row[0]->note; ?></textarea>
              </div>

            </div>

            <div class="col-md-4">

              <?php if($_REQUEST['mode'] == 'add'){ ?>
               <div class="col-12">
                  <label for="inputName5" class="form-label">Payment Method</label>
                 <select name="select_opt" id="select_opt" class="form-select" onchange="showfield(this.options[this.selectedIndex].value)" required> 
                        <option value="">Please Payment Method</option>

                        <option value="Cash"<?php if($row[0]->select_opt == 'Cash'){ ?> selected="selected" <?php } ?>>Cash payment</option>

                        <option value="Cheque"<?php if($row[0]->select_opt == 'Cheque'){ ?> selected="selected" <?php } ?>>Cheque</option>

                        <option value="Online"<?php if($row[0]->select_opt == 'Online'){ ?> selected="selected" <?php } ?>>Online payment</option>
                      </select>
                  </div>

                  <div class="col-12" id="div1"></div>
              <?php } else { ?>
                <div class="col-12">
                  <label for="inputName5" class="form-label">Payment Method</label>
                 <select name="select_opt" id="select_opt" class="form-select" onchange="showfield(this.options[this.selectedIndex].value)" required> 
                        <option value="">Please Payment Method</option>

                        <option value="Cash"<?php if($row[0]->select_opt == 'Cash'){ ?> selected="selected" <?php } ?>>Cash payment</option>

                        <option value="Cheque"<?php if($row[0]->select_opt == 'Cheque'){ ?> selected="selected" <?php } ?>>Cheque</option>

                        <option value="Online"<?php if($row[0]->select_opt == 'Online'){ ?> selected="selected" <?php } ?>>Online payment</option>
                      </select>
                  </div>
                  <div class="col-12" id="div1">
                  <?php 
                  if($row[0]->select_opt == 'Cheque'){
                    ?>
                    <label for="inputamonunt5" class="form-label">Cheque ID</label><input type="text" name="chque_no" class="form-control" id="inputamonunt5" placeholder="Enter UPI No" value="<?php echo $row[0]->chque_no; ?>">
                    <?php
                    }elseif($row[0]->select_opt == 'Online'){
                    ?>
                      <label for="inputamonunt5" class="form-label">UPI ID</label><input type="text" name="upi" class="form-control" id="inputamonunt5" placeholder="Enetr UPI ID" value="<?php echo $row[0]->upi; ?>">
                      <?php
                    }else{
                      ?>
                      <div></div>
                      <?php
                    }
                  ?>
                </div>
              <?php } ?>

              <div class="col-12">
                <label for="inputnote" class="form-label">Total Fees</label>
                <input type="text" name="totalfees" class="form-control" 
                id="inputtotalfees" placeholder="Total Fees" value="<?php echo $row[0]->totalfees; ?>">
              </div>

              <div class="" style="padding-top:32px; padding-left:0px;">
                <a href=""  onclick="myFunction()" class=" btn btn-primary">Calculator</a>
              </div>
                               
            </div>

            </div>
                
            <div class="text-end">
              <button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-success"><i class="bi bi-plus-circle"></i> Submit</button>
              <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="bi bi-dash-circle"></i> Cancel</a>
            </div>
            </form> 
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } else { ?>
   <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-table"></i> List Of <?php echo $page_nm; ?></h5>

              <!-- Table with stripped rows -->
              <table class="table datatable table-responsive">
                <thead class="text-center">
                  <tr>  
                    <th scope="col">Student Name</th>
                    <th scope="col">Payment Method</th>
                    <th scope="col">Cheque ID</th>
                    <th scope="col">UPI ID</th>
                    <th scope="col">Total fees</th>
                    <th scope="col">fees Amount</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
        ?>
                  <tr>
                    <td><?php echo $ai_core->aiGetValue(DB_PREFIX."student","name","id",$row->name);?></td>
                    <td><?php echo $row->select_opt;?></td>
                    <td><?php echo $row->chque_no;?></td>
                    <td><?php echo $row->upi;?></td>
                    <td><?php echo $row->totalfees;?></td>
                    <td><?php echo date("d-m-Y g:i A", strtotime($row->last_update));?></td>
                      <td>
                          <a href="<?php echo $pageUrl."?mode=edit&id=".$row->id.""; ?>" class="btn btn-primary m-1">Edit</a>
                          <a href="<?php echo $pageUrl."?mode=delete&id=".$row->id.""; ?>" class="delete_check btn btn-danger m-1">Delete</a>
                      </td>
                  </tr>
                   <?php }}?>
                </tbody>
              </table>
              <!-- End Table with stripped rows-->

            </div>
          </div>

        </div>
      </div>
    </section> 
     <?php } ?>
</main>


<?php include('footer.php')  ?>

<script type="text/javascript">
function showfield(name){
    if(name=='Cheque')document.getElementById('div1').innerHTML = 
    '<label for="inputamonunt5" class="form-label">Cheque ID</label><input type="text" name="chque_no" class="form-control" id="inputamonunt5" placeholder="Enter UPI No" value="<?php echo $row[0]->chque_no; ?>"></div>';

  else if(name=='Online')document.getElementById('div1').innerHTML = 
    '<label for="inputamonunt5" class="form-label">UPI ID</label><input type="text" name="upi" class="form-control" id="inputamonunt5" placeholder="Enetr UPI ID" value="<?php echo $row[0]->upi; ?>"></div>';
  else 
    document.getElementById('div1').innerHTML='';
}

function myFunction() {
  window.open("calculater2.php", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=450");
}

  $(document).ready(function(){
    var maxField = 5; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div class="row pt-2"><input type="hidden" name="fees_id[]" value=""><div class="col-md-5"><input type="text" name="new_fees[]" class="form-control" id="inputoldfees5" placeholder="Enetr Amounnt" value="<?php echo $row[0]->class; ?>"></div><div class="col-md-5"><select class="form-select" name="description[]"><option value="">Selact Fees Name</option><?php
$qrys = "SELECT * FROM tbl_fees_type order by fees_name ASC";$rows = $ai_db->aiGetQueryObj($qrys);
foreach($rows as $mcrow){?><option <?php if($row[0]->description == $mcrow->id) { ?> selected <?php  } ?> value="<?php echo $mcrow->fees_name; ?>"><?php echo $mcrow->fees_name; ?></option><?php } ?></select></div><a href="javascript:void(0);" class="remove_button btn btn-danger" style="width:40px;height:35px;margin-left:12px"><i class="bi bi-dash-circle"></i></a></div>'; //New input field html
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>
